
public class question_2 
{
	public static void main (String[] args)
	{
		House house1 = new House();
		House house2 = new House(2, 130000.0, "detached");
		House house3 = new House(220000.0);
		House house4 = new House(4, 200000.0);
		
		System.out.println("House H1: This house is type " + house1.getHouseType() + ". Its age is " + house1.getHouseAge() + " and costs $"
							+ house1.getHouseCost());
		
		System.out.println("House H2: This house is type " + house2.getHouseType() + ". Its age is " + house2.getHouseAge() + " and costs $"
				+ house2.getHouseCost());
		
		System.out.println("House H3: This house is type " + house3.getHouseType() + ". Its age is " + house3.getHouseAge() + " and costs $"
				+ house3.getHouseCost());
		
		System.out.println("House H4: This house is type " + house4.getHouseType() + ". Its age is " + house4.getHouseAge() + " and costs $"
				+ house4.getHouseCost());
			
		System.out.println("\nAccessor methods: The housetype for house H4 is "+ house4.getHouseType() + ", its age is " + 
								house4.getHouseAge()+ ", and it costs $" + house4.getHouseCost());
		
		System.out.println("\nThe estimated price of house H1 is $"+ house1.estimatedPrice(50, house1.getHouseType()));
		System.out.println("The estimated price of house H2 is $"+ house2.estimatedPrice(2, "detached"));
		System.out.println("The estimated price of house H3 is $"+ house3.estimatedPrice(house2.getHouseAge(), house2.getHouseType()));
		System.out.println("The estimated price of house H4 is $"+ house4.estimatedPrice(4, house4.getHouseType()));
		
		house1.setHouseAge(5);
		System.out.println("\nMutator method: The new age for house H1 is " + house1.getHouseAge());
		
		house1.setHouseType("detached");
		System.out.println("Mutator method: The new type for house H1 is "+ house1.getHouseType());
		
		house1.setHouseCost(200000.0);
		System.out.println("Mutator method: The new cost for house H1 is "+house1.getHouseCost());
		
		house1.setHouseAge_Cost(10, 150000.0);
		System.out.println("Mutator method: The new house H1 age is "+ house1.getHouseAge() +" and its new cost is " + house1.getHouseCost()); 
		
		house1.setHouseValues(4, "attached", 200000.0);
		System.out.println("Mutator method: The new housetype for house H1 is " + house1.getHouseType() + ", its new age is "
							+ house1.getHouseAge() + " and its cost is " + house1.getHouseCost());
		
		System.out.println("\ntoString: " + house1.toString());
		
		System.out.println("\nHouses H1 and H2 are equal is "+ house1.equalsTo(house2));
		System.out.println("Houses H1 and H4 are equal is " + house1.equalsTo(house4));
		
		System.out.println("\nHouse H4 is less than H2 is " + house4.isLessThan(house2));
		System.out.println("\nHouse H4 is greater than H2 is " + house4.isGreaterThan(house2));
	}
}

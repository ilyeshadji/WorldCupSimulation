
public class House 
{
	private int age;
	private String type;
	private double cost;
	
	public House()
	{
		age = 50;
		type = "Attached";
		cost = 100000;
	}
	
	public House(double housePrice)
	{
		age = 50;
		type = "Attached";
		cost = housePrice;
		
	}
	
	public House(int houseAge, double housePrice)
	{
		age = houseAge;
		type = "Attached";
		cost = housePrice;
	}
	
	public House(int houseAge, double housePrice, String houseType)
	{
		age = houseAge;
		type = houseType;
		cost = housePrice;
	}
	
	public int getHouseAge()
	{return age;}
	
	public String getHouseType()
	{return type;}
	
	public double getHouseCost()
	{return cost;}
	
	public void setHouseAge (int houseAge)
	{age = houseAge;}
	
	public void setHouseType(String houseType) 
	{type = houseType;}
	
	public void setHouseCost(double housePrice)
	{cost = housePrice;}
	
	public void setHouseValues (int houseAge, String houseType, double housePrice)
	{
		age = houseAge;
		type = houseType;
		cost = housePrice;
	}
	
	public void setHouseAge_Cost (int houseAge, double housePrice)
	{
		age = houseAge;
		cost = housePrice;
	}
	
	public double estimatedPrice(int houseAge, String houseType)
	{
		boolean housetype1 = houseType.equalsIgnoreCase("Attached");
		boolean housetype2 = houseType.equalsIgnoreCase("Semidetached");
		boolean housetype3 = houseType.equalsIgnoreCase("detached");
		
		if(cost == 100000 && housetype1)
		{
			for (int years = 0; years<5; years++)
				cost = cost*1.01;
		}
		else
			cost = cost*1.02;
		
		if(cost == 150000 && housetype2)
			{
				for (int years = 0; years<5; years++)
					cost = cost*1.03;
			}
		else
			cost = cost*1.03;
		
		if(cost == 200000 && housetype3)
			{
				for (int years = 0; years<5; years++)
					cost = cost*1.02;
			}
		else
			cost=cost*1.02;
		
		return cost;
	}
	
	public String toString()
	{
		return ("This House is type " + type + ". " + "Its age is " + age + " and costs $" + cost);
	}

	public boolean equalsTo(House house2)
	{
		if (getHouseAge()== house2.getHouseAge() && getHouseType().equals(getHouseType()))
			return true;
		else
			return false;
	}
	
	public boolean isLessThan(House house2)
	{
		if (getHouseCost() > house2.getHouseCost())
			return false;
		else
			return true;
	}
	
	public boolean isGreaterThan(House house2)
	{
		if (getHouseCost() < house2.getHouseCost())
			return false;
		else
			return true;
	}
	
	
	
}
